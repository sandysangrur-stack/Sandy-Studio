import { createClient } from "@supabase/supabase-js";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL ?? "";
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const supabaseReady = Boolean(url && key && !url.includes("YOUR-PROJECT"));
export const supabase = createClient(
  supabaseReady ? url : "https://example.supabase.co",
  supabaseReady ? key : "placeholder-key",
  { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } }
);