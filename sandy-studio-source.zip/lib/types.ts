export type Booking = {
  id: string; customer_name: string; phone: string; event_type: string;
  event_date: string; location: string; total_amount: number; advance_amount: number;
  status: "booked" | "completed" | "cancelled"; notes?: string;
};
export type Expense = {
  id: string; booking_id?: string | null; title: string; category: string;
  amount: number; expense_date: string; team_member?: string | null; member_count: number;
};