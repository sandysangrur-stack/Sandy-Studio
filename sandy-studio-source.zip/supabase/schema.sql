-- Sandy Studio database schema for Supabase
-- For a private single-owner workspace, sign in via Supabase Auth and use these RLS policies.
create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  event_type text not null default 'LED Screen',
  event_date date not null,
  location text not null default '',
  total_amount numeric(12,2) not null default 0 check (total_amount >= 0),
  advance_amount numeric(12,2) not null default 0 check (advance_amount >= 0 and advance_amount <= total_amount),
  status text not null default 'booked' check (status in ('booked','completed','cancelled')),
  notes text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete set null,
  title text not null,
  category text not null default 'Other',
  amount numeric(12,2) not null check (amount > 0),
  expense_date date not null default current_date,
  team_member text,
  member_count integer not null default 1 check (member_count >= 1),
  created_at timestamptz not null default now()
);

alter table public.bookings enable row level security;
alter table public.expenses enable row level security;

-- MVP single-owner policies: only authenticated users can read/write.
-- For multi-user teams, add owner_id and restrict each policy to auth.uid() = owner_id.
create policy "authenticated users can manage bookings" on public.bookings
  for all to authenticated using (true) with check (true);
create policy "authenticated users can manage expenses" on public.expenses
  for all to authenticated using (true) with check (true);

-- Important: do not use the service_role key in the app.
