import React, { useEffect, useMemo, useState } from "react";
import { Alert, Linking, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { supabase, supabaseReady } from "../lib/supabase";
import type { Booking, Expense } from "../lib/types";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

type Tab = "Dashboard" | "Bookings" | "Expenses";
const money = (n: number) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });
const today = new Date().toISOString().slice(0, 10);
const notify = (message: string) => Platform.OS === "web" ? window.alert(message) : Alert.alert("Sandy Studio", message);

export default function Home() {
  const [tab, setTab] = useState<Tab>("Dashboard");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [expenseOpen, setExpenseOpen] = useState(false);
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [eventType, setEventType] = useState("LED Screen");
  const [eventDate, setEventDate] = useState(today);
  const [location, setLocation] = useState("");
  const [total, setTotal] = useState("");
  const [advance, setAdvance] = useState("");
  const [notes, setNotes] = useState("");
  const [expenseTitle, setExpenseTitle] = useState("Transport");
  const [expenseCategory, setExpenseCategory] = useState("Transport");
  const [expenseAmount, setExpenseAmount] = useState("");
  const [expenseDate, setExpenseDate] = useState(today);
  const [teamMember, setTeamMember] = useState("");
  const [memberCount, setMemberCount] = useState("1");

  const load = async () => {
    if (!supabaseReady) return;
    setLoading(true);
    const [b, e] = await Promise.all([
      supabase.from("bookings").select("*").order("event_date", { ascending: true }),
      supabase.from("expenses").select("*").order("expense_date", { ascending: false })
    ]);
    if (b.error) notify("Bookings load nahi hue: " + b.error.message);
    else setBookings((b.data || []) as Booking[]);
    if (e.error) notify("Expenses load nahi hue: " + e.error.message);
    else setExpenses((e.data || []) as Expense[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const totalBooked = bookings.reduce((s, b) => s + Number(b.total_amount), 0);
  const received = bookings.reduce((s, b) => s + Number(b.advance_amount), 0);
  const pending = bookings.filter(b => b.status !== "cancelled").reduce((s, b) => s + Math.max(0, Number(b.total_amount) - Number(b.advance_amount)), 0);
  const expenseTotal = expenses.reduce((s, e) => s + Number(e.amount), 0);
  const profit = received - expenseTotal;
  const upcoming = useMemo(() => bookings.filter(b => b.event_date >= today && b.status === "booked"), [bookings]);

  const addBooking = async () => {
    if (!customer.trim() || !phone.trim() || !eventDate || Number(total) < 0 || Number(advance) < 0 || Number(advance) > Number(total)) {
      notify("Customer, phone, event date aur valid amount bharein. Advance total se zyada nahi ho sakta."); return;
    }
    if (!supabaseReady) { notify("Pehle Supabase configure karein. Setup instructions README.md mein hain."); return; }
    const { error } = await supabase.from("bookings").insert({
      customer_name: customer.trim(), phone: phone.trim(), event_type: eventType.trim() || "LED Screen",
      event_date: eventDate, location: location.trim(), total_amount: Number(total || 0),
      advance_amount: Number(advance || 0), status: "booked", notes: notes.trim()
    });
    if (error) { notify("Booking save nahi hui: " + error.message); return; }
    setCustomer(""); setPhone(""); setLocation(""); setTotal(""); setAdvance(""); setNotes(""); setFormOpen(false);
    await load(); notify("Booking save ho gayi.");
  };

  const addExpense = async () => {
    if (!expenseTitle.trim() || Number(expenseAmount) <= 0) { notify("Expense ka naam aur amount bharein."); return; }
    if (!supabaseReady) { notify("Pehle Supabase configure karein. Setup README.md mein hai."); return; }
    const { error } = await supabase.from("expenses").insert({
      title: expenseTitle.trim(), category: expenseCategory, amount: Number(expenseAmount),
      expense_date: expenseDate, team_member: teamMember.trim() || null, member_count: Math.max(1, Number(memberCount) || 1)
    });
    if (error) { notify("Expense save nahi hua: " + error.message); return; }
    setExpenseAmount(""); setTeamMember(""); setExpenseOpen(false); await load(); notify("Expense save ho gaya.");
  };

  const updateStatus = async (b: Booking, status: Booking["status"]) => {
    if (!supabaseReady) return;
    const { error } = await supabase.from("bookings").update({ status }).eq("id", b.id);
    if (error) notify(error.message); else await load();
  };
  const makeInvoice = async (b: Booking) => {
    const balance = Math.max(0, Number(b.total_amount) - Number(b.advance_amount));
    const html = `<html><body style="font-family:Arial;padding:28px;color:#18233b"><h1>Sandy Studio</h1><h3>LED Event Invoice</h3><hr/><p><b>Customer:</b> ${escapeHtml(b.customer_name)}</p><p><b>Phone:</b> ${escapeHtml(b.phone)}</p><p><b>Event:</b> ${escapeHtml(b.event_type)}</p><p><b>Date:</b> ${escapeHtml(b.event_date)}</p><p><b>Location:</b> ${escapeHtml(b.location || "-")}</p><hr/><p>Total amount: ${money(b.total_amount)}</p><p>Advance received: ${money(b.advance_amount)}</p><h2>Pending: ${money(balance)}</h2><p>Thank you for choosing Sandy Studio.</p></body></html>`;
    try {
      if (Platform.OS === "web") { await Print.printAsync({ html }); }
      else { const result = await Print.printToFileAsync({ html }); if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(result.uri); else notify("PDF saved: " + result.uri); }
    } catch { notify("Invoice PDF generate nahi ho saka."); }
  };
  const sendWhatsApp = async (b: Booking) => {
    const balance = Math.max(0, Number(b.total_amount) - Number(b.advance_amount));
    const digits = b.phone.replace(/\D/g, "");
    const phoneWithCountry = digits.startsWith("91") ? digits : "91" + digits.replace(/^0+/, "");
    const message = `Namaste ${b.customer_name}, Sandy Studio ki taraf se payment reminder. Event: ${b.event_type}, Date: ${b.event_date}. Total: ${money(b.total_amount)}, Advance: ${money(b.advance_amount)}, Pending: ${money(balance)}. Dhanyavaad!`;
    const url = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(message)}`;
    try { await Linking.openURL(url); } catch { notify("WhatsApp link open nahi ho saka."); }
  };

  return <View style={s.page}>
    <View style={s.header}><View><Text style={s.brand}>SANDY STUDIO</Text><Text style={s.subtitle}>LED Event Business Manager</Text></View><TouchableOpacity style={s.refresh} onPress={load}><Text style={s.refreshText}>{loading ? "Loading…" : "↻ Refresh"}</Text></TouchableOpacity></View>
    {!supabaseReady && <View style={s.warning}><Text style={s.warningText}>Cloud database setup pending — README.md follow karein. Data abhi save nahi hoga.</Text></View>}
    <View style={s.nav}>{(["Dashboard","Bookings","Expenses"] as Tab[]).map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={[s.navItem, tab === t && s.navActive]}><Text style={[s.navText, tab === t && s.navTextActive]}>{t}</Text></TouchableOpacity>)}</View>
    <ScrollView contentContainerStyle={s.content}>
      {tab === "Dashboard" && <>
        <Text style={s.heading}>Business Overview</Text>
        <View style={s.metrics}>
          <Metric label="Total Booking Value" value={money(totalBooked)} />
          <Metric label="Advance Received" value={money(received)} />
          <Metric label="Pending Payments" value={money(pending)} />
          <Metric label="Recorded Expenses" value={money(expenseTotal)} />
          <Metric label="Cash Flow* " value={money(profit)} />
          <Metric label="Upcoming Events" value={String(upcoming.length)} />
        </View>
        <Text style={s.hint}>*Cash flow = advance received − recorded expenses. Final profit should account for all payments and expenses.</Text>
        <Text style={s.heading}>Upcoming Events</Text>
        {upcoming.length === 0 ? <Empty text="Abhi upcoming booking nahi hai." /> : upcoming.slice(0, 8).map(b => <BookingCard key={b.id} booking={b} onInvoice={makeInvoice} onWhatsApp={sendWhatsApp} onStatus={updateStatus} />)}
      </>}
      {tab === "Bookings" && <>
        <View style={s.sectionHeader}><Text style={s.heading}>Event Bookings</Text><TouchableOpacity style={s.primary} onPress={() => setFormOpen(v => !v)}><Text style={s.primaryText}>{formOpen ? "Cancel" : "+ New Booking"}</Text></TouchableOpacity></View>
        {formOpen && <View style={s.form}>
          <Field label="Customer name *" value={customer} onChangeText={setCustomer} placeholder="Customer name"/>
          <Field label="Mobile number *" value={phone} onChangeText={setPhone} placeholder="e.g. 9876543210" keyboardType="phone-pad"/>
          <Field label="Event type" value={eventType} onChangeText={setEventType} placeholder="Wedding, party, LED screen"/>
          <Field label="Event date (YYYY-MM-DD) *" value={eventDate} onChangeText={setEventDate} placeholder="2026-12-31"/>
          <Field label="Venue / location" value={location} onChangeText={setLocation} placeholder="Event location"/>
          <Field label="Total amount (₹)" value={total} onChangeText={setTotal} placeholder="0" keyboardType="numeric"/>
          <Field label="Advance received (₹)" value={advance} onChangeText={setAdvance} placeholder="0" keyboardType="numeric"/>
          <Field label="Notes" value={notes} onChangeText={setNotes} placeholder="Extra details"/>
          <TouchableOpacity style={s.primary} onPress={addBooking}><Text style={s.primaryText}>Save Booking</Text></TouchableOpacity>
        </View>}
        {bookings.length === 0 ? <Empty text="Booking list khaali hai."/> : bookings.map(b => <BookingCard key={b.id} booking={b} onInvoice={makeInvoice} onWhatsApp={sendWhatsApp} onStatus={updateStatus}/>)}
      </>}
      {tab === "Expenses" && <>
        <View style={s.sectionHeader}><Text style={s.heading}>Expenses & Team</Text><TouchableOpacity style={s.primary} onPress={() => setExpenseOpen(v => !v)}><Text style={s.primaryText}>{expenseOpen ? "Cancel" : "+ Add Expense"}</Text></TouchableOpacity></View>
        {expenseOpen && <View style={s.form}>
          <Field label="Expense title" value={expenseTitle} onChangeText={setExpenseTitle} placeholder="Transport, food, labour"/>
          <Field label="Category" value={expenseCategory} onChangeText={setExpenseCategory} placeholder="Transport / Team / Other"/>
          <Field label="Amount (₹)" value={expenseAmount} onChangeText={setExpenseAmount} placeholder="0" keyboardType="numeric"/>
          <Field label="Expense date (YYYY-MM-DD)" value={expenseDate} onChangeText={setExpenseDate} placeholder={today}/>
          <Field label="Team member name (optional)" value={teamMember} onChangeText={setTeamMember} placeholder="Member name"/>
          <Field label="Team members count" value={memberCount} onChangeText={setMemberCount} placeholder="1" keyboardType="numeric"/>
          <TouchableOpacity style={s.primary} onPress={addExpense}><Text style={s.primaryText}>Save Expense</Text></TouchableOpacity>
        </View>}
        {expenses.length === 0 ? <Empty text="Abhi expenses add nahi hue."/> : expenses.map(e => <View key={e.id} style={s.card}><View style={s.cardTop}><Text style={s.cardTitle}>{e.title}</Text><Text style={s.amount}>{money(e.amount)}</Text></View><Text style={s.muted}>{e.category} · {e.expense_date}</Text><Text style={s.body}>Team: {e.team_member || "—"} · Members: {e.member_count}</Text></View>)}
      </>}
      <Text style={s.footer}>Sandy Studio · Keep your bookings and payments organised</Text>
    </ScrollView>
  </View>;
}
function escapeHtml(value: string) { return value.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c] || c)); }
function Metric({label,value}:{label:string;value:string}) { return <View style={s.metric}><Text style={s.metricLabel}>{label}</Text><Text style={s.metricValue}>{value}</Text></View>; }
function Field(props: {label:string;value:string;onChangeText:(v:string)=>void;placeholder:string;keyboardType?:"default"|"numeric"|"phone-pad"}) { return <View style={s.field}><Text style={s.fieldLabel}>{props.label}</Text><TextInput style={s.input} value={props.value} onChangeText={props.onChangeText} placeholder={props.placeholder} keyboardType={props.keyboardType || "default"} placeholderTextColor="#8490a6"/></View>; }
function Empty({text}:{text:string}) { return <View style={s.empty}><Text style={s.muted}>{text}</Text></View>; }
function BookingCard({booking:b,onInvoice,onWhatsApp,onStatus}:{booking:Booking;onInvoice:(b:Booking)=>void;onWhatsApp:(b:Booking)=>void;onStatus:(b:Booking,status:Booking["status"])=>void}) {
  const balance = Math.max(0, Number(b.total_amount)-Number(b.advance_amount));
  return <View style={s.card}><View style={s.cardTop}><Text style={s.cardTitle}>{b.customer_name}</Text><Text style={s.amount}>{money(balance)} due</Text></View><Text style={s.muted}>{b.event_type} · {b.event_date} · {b.status}</Text><Text style={s.body}>Phone: {b.phone} · {b.location || "Location not added"}</Text><Text style={s.body}>Total {money(b.total_amount)} · Advance {money(b.advance_amount)}</Text><View style={s.actions}><SmallButton label="Invoice PDF / Print" onPress={() => onInvoice(b)}/><SmallButton label="WhatsApp Reminder" onPress={() => onWhatsApp(b)}/>{b.status === "booked" && <SmallButton label="Mark completed" onPress={() => onStatus(b,"completed")}/>}</View></View>;
}
function SmallButton({label,onPress}:{label:string;onPress:()=>void}) { return <TouchableOpacity style={s.smallButton} onPress={onPress}><Text style={s.smallButtonText}>{label}</Text></TouchableOpacity>; }
const s = StyleSheet.create({
 page:{flex:1,backgroundColor:"#f4f6fb"},header:{backgroundColor:"#fff",paddingHorizontal:22,paddingTop:Platform.OS==="web"?22:52,paddingBottom:18,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderBottomWidth:1,borderBottomColor:"#e6eaf2"},
 brand:{fontSize:22,fontWeight:"900",letterSpacing:1.5,color:"#16213e"},subtitle:{fontSize:12,color:"#68748b",marginTop:3},refresh:{paddingVertical:9,paddingHorizontal:12,borderRadius:10,backgroundColor:"#edf2ff"},refreshText:{color:"#314c9b",fontWeight:"700"},
 warning:{backgroundColor:"#fff4d6",padding:12},warningText:{color:"#795400",fontSize:12},nav:{flexDirection:"row",backgroundColor:"#fff",paddingHorizontal:16,borderBottomWidth:1,borderBottomColor:"#e6eaf2"},navItem:{paddingVertical:14,paddingHorizontal:15,borderBottomWidth:3,borderBottomColor:"transparent"},navActive:{borderBottomColor:"#3757c8"},navText:{color:"#68748b",fontWeight:"600"},navTextActive:{color:"#263f9f"},content:{padding:18,maxWidth:1050,width:"100%",alignSelf:"center",paddingBottom:48},
 heading:{fontSize:20,fontWeight:"800",color:"#19243c",marginTop:6,marginBottom:14},metrics:{flexDirection:"row",flexWrap:"wrap",gap:12},metric:{backgroundColor:"#fff",padding:16,borderRadius:14,minWidth:145,flexGrow:1,borderWidth:1,borderColor:"#e8ebf3"},metricLabel:{fontSize:12,color:"#718096",marginBottom:8},metricValue:{fontSize:20,fontWeight:"800",color:"#1b2b53"},hint:{fontSize:11,color:"#778196",marginTop:10,marginBottom:18},
 sectionHeader:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",gap:12,marginBottom:10},primary:{backgroundColor:"#304ec1",paddingVertical:11,paddingHorizontal:15,borderRadius:10,alignItems:"center",marginTop:8},primaryText:{color:"#fff",fontWeight:"700"},form:{backgroundColor:"#fff",padding:16,borderRadius:14,borderWidth:1,borderColor:"#e6eaf2",marginBottom:18},field:{marginBottom:12},fieldLabel:{fontSize:12,fontWeight:"700",color:"#48546b",marginBottom:5},input:{borderWidth:1,borderColor:"#dce2ee",borderRadius:9,paddingHorizontal:12,paddingVertical:11,color:"#1c2943",backgroundColor:"#fbfcff"},card:{backgroundColor:"#fff",borderRadius:14,padding:16,marginBottom:12,borderWidth:1,borderColor:"#e7eaf2"},cardTop:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",gap:8},cardTitle:{fontSize:16,fontWeight:"800",color:"#1d2942",flexShrink:1},amount:{fontSize:14,fontWeight:"800",color:"#b45309"},muted:{fontSize:12,color:"#78849a",marginTop:6},body:{fontSize:13,color:"#45516a",marginTop:7},actions:{flexDirection:"row",flexWrap:"wrap",gap:7,marginTop:12},smallButton:{paddingVertical:8,paddingHorizontal:10,backgroundColor:"#eef2ff",borderRadius:8},smallButtonText:{fontSize:11,color:"#2e469b",fontWeight:"700"},empty:{backgroundColor:"#fff",borderRadius:12,padding:24,alignItems:"center",marginBottom:12},footer:{textAlign:"center",fontSize:11,color:"#8b95a8",marginTop:20}
});